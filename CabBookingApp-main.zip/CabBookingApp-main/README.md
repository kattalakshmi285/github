# CabBookingApp
This is a Cab booking system website made using MongoDB, Express.js, React and  Node.js(MERN).
